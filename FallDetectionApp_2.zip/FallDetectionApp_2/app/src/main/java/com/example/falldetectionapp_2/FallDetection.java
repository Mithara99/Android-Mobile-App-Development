package com.example.falldetectionapp_2;

import android.hardware.SensorEvent;
import android.hardware.Sensor;

public class FallDetection {

    // State machine states
    private static final int STATE_IDLE = 0;
    private static final int STATE_FALLING = 1;
    private static final int STATE_IMPACT = 2;
    private static final int STATE_RECOVERY = 3;

    // Thresholds
    private static final float ACCELERATION_THRESHOLD_LOW = 2.0f; // Free fall threshold
    private static final float ACCELERATION_THRESHOLD_HIGH = 8.0f; // Impact threshold
    private static final float GYROSCOPE_THRESHOLD = 3.0f; // Orientation change threshold

    private int currentState = STATE_IDLE;

    public boolean detectFall(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float accelerationMagnitude = (float) Math.sqrt(x * x + y * y + z * z);

            switch (currentState) {
                case STATE_IDLE:
                    if (accelerationMagnitude < ACCELERATION_THRESHOLD_LOW) {
                        currentState = STATE_FALLING;
                    }
                    break;
                case STATE_FALLING:
                    if (accelerationMagnitude > ACCELERATION_THRESHOLD_HIGH) {
                        currentState = STATE_IMPACT;
                    }
                    break;
                case STATE_IMPACT:
                    // Wait for gyroscope data to confirm fall
                    break;
                case STATE_RECOVERY:
                    if (accelerationMagnitude > ACCELERATION_THRESHOLD_LOW && accelerationMagnitude < ACCELERATION_THRESHOLD_HIGH) {
                        currentState = STATE_IDLE;
                    }
                    break;
            }
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            float gyroscopeMagnitude = (float) Math.sqrt(x * x + y * y + z * z);

            if (currentState == STATE_IMPACT || gyroscopeMagnitude > GYROSCOPE_THRESHOLD) {
                currentState = STATE_RECOVERY;
                return true; // Fall detected
            }
        }

        return false; // No fall detected
    }
}
